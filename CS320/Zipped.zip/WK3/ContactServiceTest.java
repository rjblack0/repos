import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {                   //ContactService testing for adding deleteing and updating by contact ID.


    @Test
    void testAddContactSuccess() {                              //Test adding contact
        ContactService service = new ContactService();

        service.addContact("1", "John", "Doe",
                           "1234567890", "123 Main Street");

        Contact contact = service.getContactForTest("1");
        assertNotNull(contact);
        assertEquals("John", contact.getFirstName());
    }

    @Test
    void testAddContactDuplicateIdThrowsException() {               //Test duplicate ID exception
        ContactService service = new ContactService();

        service.addContact("1", "John", "Doe",
                           "1234567890", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact("1", "Jane", "Smith",
                               "0987654321", "456 Second Street");
        });
    }

    @Test
    void testDeleteContactRemovesContact() {                    //Test deletion
        ContactService service = new ContactService();

        service.addContact("1", "John", "Doe",
                           "1234567890", "123 Main Street");

        service.deleteContact("1");

        assertNull(service.getContactForTest("1"));     //check for deletion
    }

    @Test
    void testDeleteNonExistingContactThrowsException() {        //Test duplication ID deletion exception
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("999");
        });
    }

    @Test
    void testUpdateFirstName() {                                //Test firstName update
        ContactService service = new ContactService();

        service.addContact("1", "John", "Doe",
                           "1234567890", "123 Main Street");

        service.updateFirstName("1", "Jane");

        Contact contact = service.getContactForTest("1");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    void testUpdatePhone() {                                    //Test phone number update
        ContactService service = new ContactService();

        service.addContact("1", "John", "Doe",
                           "1234567890", "123 Main Street");

        service.updatePhone("1", "0987654321");

        Contact contact = service.getContactForTest("1");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    void testUpdateNonExistingContactThrowsException() {        //Test updating contact exception
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "NewName");
        });
    }
}
