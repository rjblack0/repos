import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void testValidContactCreation() {                                       //Test Happy Path
        Contact contact = new Contact("12345", "John", "Doe",
                                      "1234567890", "123 Main Street");

        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    // contactId tests.

    @Test
    void testContactIdTooLong() {                               //check for longer than 10
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe",
                        "1234567890", "123 Main Street");
        });
    }

    @Test
    void testContactIdNull() {                                  //check for Null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe",
                        "1234567890", "123 Main Street");
        });
    }

    //firstName tests

    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "ANAMETHATISTOOLONGOOOO", "Doe",
                        "1234567890", "123 Main Street");
        });
    }

    @Test
    void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Doe",
                        "1234567890", "123 Main Street");
        });
    }

    //lastName tests

    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "ANAMETHATISTOOLONGOOOO",
                        "1234567890", "123 Main Street");
        });
    }

    @Test
    void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", null,
                        "1234567890", "123 Main Street");
        });
    }

    //phone tests

    @Test
    void testPhoneWrongLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe",
                        "123456789", "123 Main Street");
        });
    }

    @Test
    void testPhoneNonDigitCharacters() {                            //letters test
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe",
                        "12345abcde", "123 Main Street");
        });
    }

    @Test
    void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe",
                        null, "123 Main Street");
        });
    }

    //address tests

    @Test
    void testAddressTooLong() {
        String longAddress = "ThirtyCharactersOOOOOOOOOOOOOOOOO";
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe",
                        "1234567890", longAddress);
        });
    }

    @Test
    void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe",
                        "1234567890", null);
        });
    }

    //update methods tests

    @Test
    void testUpdateFirstNameValid() {                                       //Testing that firstName can be updated
        Contact contact = new Contact("12345", "John", "Doe",
                                      "1234567890", "123 Main Street");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }


    @Test
    void testUpdateFirstNameInvalid() {                                     //Testing that lastName can be updated.
        Contact contact = new Contact("12345", "John", "Doe",
                                      "1234567890", "123 Main Street");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("ANAMETHATISTOOLONGOOOO");
        });
    }
}
