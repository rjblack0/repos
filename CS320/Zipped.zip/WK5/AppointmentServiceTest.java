package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Appointment;
import main.AppointmentService;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
    }

    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 3600_000L);
    }

    @Test
    void testAddAppointmentSuccessfully() {
        Date futureDate = getFutureDate();
        appointmentService.addAppointment("A001", futureDate, "Dentist appointment");

        Appointment appt = appointmentService.getAppointment("A001");
        assertNotNull(appt);
        assertEquals("A001", appt.getAppointmentId());
        assertEquals("Dentist appointment", appt.getDescription());
    }

    @Test
    void testAddAppointmentWithDuplicateIdThrowsException() {
        Date futureDate1 = getFutureDate();
        Date futureDate2 = getFutureDate();

        appointmentService.addAppointment("A001", futureDate1, "First appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment("A001", futureDate2, "Second appointment");
        });
    }

    @Test
    void testDeleteAppointmentSuccessfully() {
        Date futureDate = getFutureDate();
        appointmentService.addAppointment("A001", futureDate, "Dentist appointment");

        appointmentService.deleteAppointment("A001");

        Appointment appt = appointmentService.getAppointment("A001");
        assertNull(appt);
    }

    @Test
    void testDeleteNonexistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("DOES_NOT_EXIST");
        });
    }
}
