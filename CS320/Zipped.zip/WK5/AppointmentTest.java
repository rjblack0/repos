package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import main.Appointment;

public class AppointmentTest {

    private Date getFutureDate() {                                          //Create dates 1 hour in future
        return new Date(System.currentTimeMillis() + 3600_000L);
    }

    private Date getPastDate() {                                            //1 hour in past
        return new Date(System.currentTimeMillis() - 3600_000L);
    }

    @Test
    void testValidAppointmentCreation() {
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment("12345", futureDate, "Regular checkup");

        assertNotNull(appointment);
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Regular checkup", appointment.getDescription());
    }

    @Test
    void testAppointmentIdCannotBeNull() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Description");
        });
    }

    @Test
    void testAppointmentIdTooLong() {
        Date futureDate = getFutureDate();
        // 11 characters
        String longId = "12345678901";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(longId, futureDate, "Description");
        });
    }

    @Test
    void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Description");
        });
    }

    @Test
    void testAppointmentDateCannotBeInPast() {
        Date pastDate = getPastDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Description");
        });
    }

    @Test
    void testDescriptionCannotBeNull() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }

    @Test
    void testDescriptionTooLong() {
        Date futureDate = getFutureDate();
        // 51 characters
        String longDescription = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXY"; 
        assertEquals(51, longDescription.length());

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, longDescription);
        });
    }
}
