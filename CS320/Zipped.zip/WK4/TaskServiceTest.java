import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {                 //TaskService testing for adding deleting and updating by task ID.

    @Test
    void testAddTaskSuccess() {                             //Test adding task
        TaskService service = new TaskService();

        service.addTask("1", "Do Homework",
                        "Complete CS-320 Milestone");

        Task task = service.getTaskForTest("1");
        assertNotNull(task);
        assertEquals("Do Homework", task.getName());
        assertEquals("Complete CS-320 Milestone", task.getDescription());
    }

    @Test
    void testAddTaskDuplicateIdThrowsException() {          //Test duplicate ID exception
        TaskService service = new TaskService();

        service.addTask("1", "Do Homework",
                        "Complete CS-320 Milestone");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask("1", "Do Laundry",
                            "Wash and fold clothes");
        });
    }
    @Test
    void testDeleteTaskRemovesTask() {                      //Test deletion
        TaskService service = new TaskService();

        service.addTask("1", "Do Homework",
                        "Complete CS-320 Milestone");

        service.deleteTask("1");

        assertNull(service.getTaskForTest("1"));            //check that deletion was successful
    }
    @Test
    void testDeleteNonExistingTaskThrowsException() {       //Test deletion exception
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }
    @Test
    void testUpdateName() {                                 //Test name update
        TaskService service = new TaskService();

        service.addTask("1", "Do Homework",
                        "Complete CS-320 Milestone");

        service.updateName("1", "Do Project");

        Task task = service.getTaskForTest("1");
        assertEquals("Do Project", task.getName());
    }

    @Test
    void testUpdateDescription() {                          //Test description update
        TaskService service = new TaskService();

        service.addTask("1", "Do Homework",
                        "Complete CS-320 Milestone");

        service.updateDescription("1", "Finish Milestone 4 this weekend");

        Task task = service.getTaskForTest("1");
        assertEquals("Finish Milestone 4 this weekend", task.getDescription());
    }

    @Test
    void testUpdateNonExistingTaskThrowsException() {           //Test updating task exception
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("999", "New Name");
        });
    }
}
