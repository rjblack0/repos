import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    void testValidTaskCreation() {                                         //Test Happy Path
        Task task = new Task("12345", "Do Homework",
                             "Complete CS-320 Milestone");

        assertEquals("12345", task.getTaskId());
        assertEquals("Do Homework", task.getName());
        assertEquals("Complete CS-320 Milestone", task.getDescription());
    }

    @Test
    void testTaskIdTooLong() {                                             //taskID not longer than 10
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Do Homework",
                     "Complete CS-320 Milestone");
        });
    }

    @Test
    void testTaskIdNull() {                                                //taskID not null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Do Homework",
                     "Complete CS-320 Milestone");
        });
    }

    @Test
    void testNameTooLong() {
        String longName = "ThisTaskNameIsWayTooLongForField";              //Name greater than 20 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", longName,
                     "Complete CS-320 Milestone");
        });
    }

    @Test
    void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null,
                     "Complete CS-320 Milestone");
        });
    }

    @Test
    void testDescriptionTooLong() {
        String longDescription =
            "This description is intentionally made longer than fifty characters "
          + "to trigger validation";
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Do Homework", longDescription);
        });
    }

    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Do Homework", null);
        });
    }

    @Test
    void testUpdateNameValid() {                                           //Method update, test name can be updated
        Task task = new Task("12345", "Do Homework",
                             "Complete CS-320 Milestone");
        task.setName("Do Project");
        assertEquals("Do Project", task.getName());
    }

    @Test
    void testUpdateNameInvalid() {                                         //invalid name update
        Task task = new Task("12345", "Do Homework",
                             "Complete CS-320 Milestone");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("ThisTaskNameIsWayTooLongForField");
        });
    }

    @Test
    void testUpdateDescriptionValid() {                                                 //Testing that description can be updated
        Task task = new Task("12345", "Do Homework",
                             "Complete CS-320 Milestone");
        task.setDescription("Finish Milestone 4 this weekend");
        assertEquals("Finish Milestone 4 this weekend", task.getDescription());
    }

    @Test
    void testUpdateDescriptionInvalid() {                                  //Testing invalid description update
        Task task = new Task("12345", "Do Homework",
                             "Complete CS-320 Milestone");
        String longDescription =
            "This description is intentionally made longer than fifty characters "
          + "to trigger validation";
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(longDescription);
        });
    }
}
